import { GetInTouch } from "../../PAGES/GetInTouch"

export const ContactUs = ()=>{
    return (
        <>
        <GetInTouch />
        </>
    )
}