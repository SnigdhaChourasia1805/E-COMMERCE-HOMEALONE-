import { AboutHeading } from "../COMPONENTS/Layout/AboutHeading"
import { AboutInfo } from "../COMPONENTS/Layout/AboutInfo"



export const About = ()=>{
    return (
        <>
        <AboutHeading />
        <AboutInfo />
        </>
    )
}